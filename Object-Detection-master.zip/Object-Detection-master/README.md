# Object-Detection
Object detection is a algorithm to detect the Object(animals, alphabets) from the given image. this is done with the help of  CNN
